var currentMusicas = [];

function parseSetlist() {
  var input = document.getElementById('listaMusicas').value;
  var linhas = input.split('\n').filter(function(l) { return l.trim() !== ''; });
  var musicas = linhas.map(function(linha) {
    var nome = linha.replace(/^[\d]+[.)]\s*/, '').replace(/^[-•]\s*/, '').trim();
    return { nome: nome, tom: '', harmonia: '', bpm: '' };
  }).filter(function(m) { return m.nome !== ''; });
  if (musicas.length === 0) { alert('Nenhuma música encontrada.'); return; }
  currentMusicas = musicas;
  renderPreview();
}

function renderPreview() {
  var preview = document.getElementById('preview');
  var musicList = document.getElementById('musicList');
  preview.style.display = 'block';
  var local = document.getElementById('local').value;
  var data = document.getElementById('dataShow').value;
  document.getElementById('previewMeta').textContent = local + ' - ' + data + ' (' + currentMusicas.length + ' músicas)';
  musicList.innerHTML = '';
  currentMusicas.forEach(function(musica, index) {
    var div = document.createElement('div');
    div.className = 'music-item';
    div.id = 'music-' + index;
    var h = '';
    h += '<span class="music-number">' + (index + 1) + '</span>';
    h += '<button class="icon-btn" onclick="MetadataEditor.show(' + index + ')" style="margin-left:4px;cursor:pointer;font-size:0.8rem;">EDITAR</button>';
    h += '<div class="music-content">';
    h += '<div class="music-name"><input type="text" value="' + escapeHtml(musica.nome) + '" onchange="updateMusicName(' + index + ', this.value)"></div>';
    h += '<div class="music-metadata" id="metadata-' + index + '">';
    h += '<label>Tom<input type="text" value="' + escapeHtml(musica.tom) + '" onchange="updateMusicMeta(' + index + ', \'tom\', this.value)"></label>';
    h += '<label>Harmonia<input type="text" value="' + escapeHtml(musica.harmonia) + '" onchange="updateMusicMeta(' + index + ', \'harmonia\', this.value)"></label>';
    h += '<label>BPM<input type="text" value="' + escapeHtml(musica.bpm) + '" onchange="updateMusicMeta(' + index + ', \'bpm\', this.value)"></label>';
    h += '</div></div>';
    h += '<div class="music-actions">';
    h += '<button class="icon-btn" onclick="toggleMetadata(' + index + ')">+</button>';
    h += '<button class="icon-btn" onclick="removeMusic(' + index + ')">x</button>';
    h += '</div>';
    div.innerHTML = h;
    musicList.appendChild(div);
  });
  preview.scrollIntoView({ behavior: 'smooth' });
}

function getMusicListFromPreview() { return currentMusicas; }
function updateMusicName(index, value) { if (currentMusicas[index]) currentMusicas[index].nome = value; }
function updateMusicMeta(index, field, value) { if (currentMusicas[index]) currentMusicas[index][field] = value; }
function toggleMetadata(index) { var item = document.getElementById('music-' + index); if (item) item.classList.toggle('expanded'); }
function removeMusic(index) { if (confirm('Remover esta música?')) { currentMusicas.splice(index, 1); renderPreview(); } }

async function saveSetlist() {
  var local = document.getElementById('local').value;
  var dataShow = document.getElementById('dataShow').value;
  if (!local || !dataShow || currentMusicas.length === 0) { showToast('Preencha todos os campos.', 'error'); return; }
  var saveBtn = document.querySelector('.preview-actions .btn-primary');
  showLoading(saveBtn);
  updateSyncStatus('saving');
  try {
    var result = await API.saveSetlist(dataShow, local, currentMusicas);
    hideLoading(saveBtn);
    showToast('Setlist salva! ' + result.qtdMusicas + ' músicas.', 'success');
    updateSyncStatus('online');
  } catch (error) {
    hideLoading(saveBtn);
    showToast('Erro: ' + error.message, 'error');
    updateSyncStatus('error');
  }
}

function clearForm() {
  if (confirm('Limpar formulário?')) {
    document.getElementById('setlistForm').reset();
    document.getElementById('preview').style.display = 'none';
    currentMusicas = [];
  }
}

function escapeHtml(text) {
  var div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}